# Bangladesh Facebook Cloning Tool

pkg update

pkg upgrade

pkg install python

pkg install python2

pkg install git

pip2 install mechanize

pip2 install requests

git clone https://github.com/Sadman-TheDentian/BDFB

cd BDFB

python2 BDclone.py


Tool Username : Dark
Tool Password : Denti

My Facebook Page : https://www.facebook.com/100844855058735
